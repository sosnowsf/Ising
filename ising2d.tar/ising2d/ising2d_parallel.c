#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<mpi.h>
#include<unistd.h>
#include"decomp1d.h"

#define m 10
#define n 10

void init_grid(int g[m][n]);
void metropolis_sweep(int g[m][n], int, int, const double , double, const double);
double energy(int g[m][n], const double);
double magnetisation(int g[m][n]);
void print_matrix(int g[m][n]);
void exchange(int g[m][n], int, int, int, int, MPI_Comm comm);
void gather(int g[m][n], int, int, int, int);
void print_in_order(int g[m][n], MPI_Comm comm);
int modulo(int, int);

int main(int argc, char **argv){
	int rank, size, s, e, nbrtop, nbrbot;
	double T = 273.15; //Start at 0 degrees Celsius
	const double J = 1.0; //Coupling constant
	const double k = pow(1.38064852, -23); //Boltzmann constant

	int seed = 1997;
	srand48(seed);

	int g[m][n]; //define grid	
	init_grid(g);

	int ndims;
	int dims[1];
	int periods[1];
	int reorder;
	int source1, source2;

	//print_matrix(g);
	//printf("%f\n", magnetisation(g));
	
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	MPI_Comm cart;
	ndims=1;
	dims[0]=size;
	periods[0]=1;
	reorder=0;

	MPI_Cart_create(MPI_COMM_WORLD, ndims, dims, periods, reorder, &cart);
	MPI_Cart_shift(cart, 0, -1, &source1, &nbrtop);
	MPI_Cart_shift(cart, 0, 1, &source2, &nbrbot);

	decomp1d(n, size, rank, &s, &e);
	//s++;
	//e++;
	printf("%d %d %d %d %d\n", rank, s, e, nbrtop, nbrbot);
	//for(int i=0; i<1000; i++){
		//metropolis_sweep(g,s,e,J,T,k);
	for(int i=s; i<e+1; i++){
		for(int j=0; j<n; j++){
			g[i][j]=i*n+j;
		}
	}
	print_in_order(g, MPI_COMM_WORLD);
	//print_matrix(g);
	/*if(rank==1){
		MPI_Send(&g[0][0], n, MPI_INT, 0, 0, MPI_COMM_WORLD);
	}
	if(rank==0){
		MPI_Recv(&g[0][0], n, MPI_INT, 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	}*/
	for(int i=0; i<1; i++){
	exchange(g,s,e,nbrtop,nbrbot,MPI_COMM_WORLD);
	//print_in_order(g, MPI_COMM_WORLD);
	}

	//}
	//print_in_order(g, MPI_COMM_WORLD);
	gather(g,s,e,rank,size);
	MPI_Barrier(MPI_COMM_WORLD);
	//print_in_order(g, MPI_COMM_WORLD);
	if(rank==0){
		//printf("%f\n", magnetisation(g));
		print_matrix(g);
	}
	//printf("%f\n", magnetisation(g));
	//print_matrix(g);

	MPI_Finalize();
return 0;
}

//Initialise grid for random start
void init_grid(int g[m][n]){
	int i,j;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			double U = drand48();
			if(U<0.5) g[i][j]=-1;
			else{ 
				g[i][j]=1;
			}
		}
	}
}

//Sweep through the lattice using the metropolis algorithm
void metropolis_sweep(int g[m][n], int s, int e, const double J, double T, const double k){
	int i,j;
	for(i=s; i<e; i++){
		for(j=0; j<n; j++){
			//Calculate the energy difference and check if spin has to be flipped
			double dE = J*g[i][j]*(g[(i+1)%m][j]+g[(i-1)&m][j]+g[i][(j+1)%n]+g[i][(j-1)%n]);
			if(dE<0) g[i][j]*=-1;
			else{
				double r = drand48();
				if(r<exp(-(1.0/k*T)*dE)){
					g[i][j]*=-1;
				}
			}
		}
	}
}

void exchange(int g[m][n], int s, int e, int nbrtop, int nbrbot, MPI_Comm comm){
	MPI_Request reqs[4];

	MPI_Irecv(&g[modulo(s-1,m)][0], n, MPI_INT, nbrtop, 0, comm, &reqs[0]);
        MPI_Irecv(&g[modulo(e+1,m)][0], n, MPI_INT, nbrbot, 0, comm, &reqs[1]);
        MPI_Isend(&g[modulo(e,m)][0], n, MPI_INT, nbrbot, 0, comm, &reqs[2]);
        MPI_Isend(&g[modulo(s,m)][0], n, MPI_INT, nbrtop, 0, comm, &reqs[3]);

	MPI_Waitall(4, reqs, MPI_STATUSES_IGNORE);
}

void gather(int g[m][n], int s, int e, int rank, int size){
	int *recvptr = &(g[0][0]);
	int recvcounts[size];
	//recvcounts[0]=e-s+1;
	int displs[size];
	//displs[0]=s*n;
	//int *recvcounts, *displs;
	//recvcounts = (int *)malloc((e-s+1)*sizeof(int));//*sizeof(int);
	//displs = (int *)malloc(s*n*sizeof(int));
	//printf("%d %d %d %d\n", recvcounts[0], displs[0], e-s+1, s*n);
	int rc = e-s+1;
	if(rank==0){
		
	}
	MPI_Gatherv(&(g[0][0]), n*(e-s+1), MPI_INT, recvptr, &recvcounts[rank], &displs[rank], MPI_INT, 0, MPI_COMM_WORLD);
}


//Calculate the energy of the system
double energy(int g[m][n], const double J){
	int i,j;
	double E=0;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			E+=-J*g[i][j]*(g[(i+1)%m][j]+g[(i-1)&m][j]+g[i][(j+1)%n]+g[i][(j-1)%n]);
		}
	}
return E;
}

//Calculate magnetisation persite
double magnetisation(int g[m][n]){
	int i,j;
	double M=0;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			M+=g[i][j];
		}
	}
return M/(m*n);
}

void print_matrix(int g[m][n]){
	int i,j;
	printf("\n");
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			printf("%d ", g[i][j]);
		}
	printf("\n");
	}
}


void print_in_order(int g[m][n], MPI_Comm comm)
{
  int myid, size;
  int i;

  MPI_Comm_rank(comm, &myid);
  MPI_Comm_size(comm, &size);
  MPI_Barrier(comm);
  printf("Attempting to print in order\n");
  sleep(1);
  MPI_Barrier(comm);

  for(i=0; i<size; i++){
    if( i == myid ){
      printf("proc %d\n",myid);
      print_matrix(g);
    }
    fflush(stdout);
    usleep(500);	
    MPI_Barrier(MPI_COMM_WORLD);
  }
}

int modulo(int a, int b){
	int r = a%b;
	if(r<0) r+=b;
return r;
}
