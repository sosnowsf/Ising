int decomp1d( int n, int size, int rank, int *s, int *e );
