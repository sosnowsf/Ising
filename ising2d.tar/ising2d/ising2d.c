#include<stdio.h>
#include<stdlib.h>
#include<math.h>
//#include<mpi.h>

#define m 50
#define n 50

void init_grid(int g[m][n]);
void metropolis_sweep(int g[m][n], const double , double, const double);
double energy(int g[m][n], const double);
double magnetisation(int g[m][n]);
void print_matrix(int g[m][n]);

int main(){
	double T = 273.15; //Start at 0 degrees Celsius
	const double J = 1.0; //Coupling constant
	const double k = pow(1.38064852, -23); //Boltzmann constant

	int seed = 1997;
	srand48(seed);
	//const int n=10;
	//const int m=10;
	int g[m][n]; //define grid
	
	init_grid(g);

	print_matrix(g);
	printf("%f\n", magnetisation(g));
	
	for(int i=0; i<1000; i++){
		metropolis_sweep(g,J,T,k);
		//energy(g,m,n);
		//printf("%f\n", magnetisation(g));
	}
	printf("%f\n", magnetisation(g));
	//g[3][5]=9;
	print_matrix(g);
return 0;
}

//Initialise grid for random start
void init_grid(int g[m][n]){
	int i,j;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			double U = drand48();
			if(U<0.5) g[i][j]=-1;
			else{ 
				g[i][j]=1;
			}
		}
	}
}

//Sweep through the lattice using the metropolis algorithm
void metropolis_sweep(int g[m][n], const double J, double T, const double k){
	int i,j;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			//Calculate the energy difference and check if spin has to be flipped
			double dE = J*g[i][j]*(g[(i+1)%m][j]+g[(i-1)&m][j]+g[i][(j+1)%n]+g[i][(j-1)%n]);
			if(dE<0) g[i][j]*=-1;
			else{
				double r = drand48();
				if(r<exp(-(1.0/k*T)*dE)){
					g[i][j]*=-1;
				}
			}
		}
	}
}

//Calculate the energy of the system
double energy(int g[m][n], const double J){
	int i,j;
	double E=0;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			E+=-J*g[i][j]*(g[(i+1)%m][j]+g[(i-1)&m][j]+g[i][(j+1)%n]+g[i][(j-1)%n]);
		}
	}
return E;
}

//Calculate magnetisation persite
double magnetisation(int g[m][n]){
	int i,j;
	double M=0;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			M+=g[i][j];
		}
	}
return M/(m*n);
}

void print_matrix(int g[m][n]){
	int i,j;
	for(i=0; i<m; i++){
		for(j=0; j<n; j++){
			printf("%d ", g[i][j]);
		}
	printf("\n");
	}
}
